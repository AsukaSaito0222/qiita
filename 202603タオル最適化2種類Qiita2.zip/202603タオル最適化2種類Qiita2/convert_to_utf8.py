#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CPLEX出力結果をUTF-8に変換するスクリプト
"""

import sys
import subprocess

def main():
    print("タオル製造最適化を実行中...")
    print()
    
    # CPLEXを実行（バイナリモードで出力を取得）
    result = subprocess.run(
        ["oplrun", "towel_optimization.mod", "towel_optimization.dat"],
        capture_output=True
    )
    
    # バイト列をデコード（複数のエンコーディングを試す）
    output_text = None
    for encoding in ['utf-8', 'cp932', 'shift_jis', 'latin1']:
        try:
            output_text = result.stdout.decode(encoding)
            print(f"デコード成功: {encoding}")
            break
        except UnicodeDecodeError:
            continue
    
    if output_text is None:
        # どのエンコーディングでも失敗した場合はエラーを無視してデコード
        output_text = result.stdout.decode('utf-8', errors='ignore')
        print("警告: 一部の文字をデコードできませんでした")
    
    # 結果をUTF-8で保存
    output_file = "optimization_result_final.txt"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(output_text)
        if result.stderr:
            try:
                stderr_text = result.stderr.decode('utf-8', errors='ignore')
                f.write("\n\n=== エラー出力 ===\n")
                f.write(stderr_text)
            except:
                pass
    
    print()
    print(f"結果を {output_file} に保存しました（UTF-8形式）。")
    print()
    
    # 結果を画面にも表示
    print("=" * 60)
    print(output_text)
    print("=" * 60)
    
    return result.returncode

if __name__ == "__main__":
    sys.exit(main())

# Made with Bob
