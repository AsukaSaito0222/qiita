/*********************************************
 * タオル製造最適化モデル
 * 
 * 目的: 綿生地とバイアステープの廃棄を最小化し、
 *       収益率を最大化する
 * 
 * 制約:
 * - 予算50,000円以内
 * - タオルA: 2枚/行（横満杯）、縦廃棄最小
 * - タオルB: 3枚/行（横5cm廃棄）、縦廃棄最小
 * - バイアステープ: 4柄同一単位数、廃棄最小
 * - バランス制約: A-B間±10、柄間±2
 *********************************************/

// パラメータ定義
int NbPatterns = 4;
range Patterns = 1..NbPatterns;
string PatternNames[Patterns] = ["花", "鳥", "草", "猫"];

// 綿生地パラメータ
float CottonWidth = 110;           // 綿生地の幅 (cm)
float CottonUnitLength = 100;      // 購入単位の長さ (cm)
float CottonUnitPrice = 1200;      // 購入単位あたりの価格 (円)
float CottonShippingThreshold = 4000;  // 送料無料の閾値 (円)
float CottonShippingFee = 980;     // 送料 (円)

// タオルAの仕様
float TowelA_Width = 55;           // タオルAの幅 (cm)
float TowelA_Height = 35;          // タオルAの高さ (cm)
float TowelA_BiasLength = 192;     // タオルAに必要なバイアステープ (cm)
float TowelA_Price = 1400;         // タオルAの販売価格 (円)
int TowelA_PerRow = 2;             // 1行あたりのタオルA枚数

// タオルBの仕様
float TowelB_Width = 35;           // タオルBの幅 (cm)
float TowelB_Height = 35;          // タオルBの高さ (cm)
float TowelB_BiasLength = 152;     // タオルBに必要なバイアステープ (cm)
float TowelB_Price = 1200;         // タオルBの販売価格 (円)
int TowelB_PerRow = 3;             // 1行あたりのタオルB枚数
float TowelB_HorizontalWaste = 5;  // タオルBの横方向廃棄 (cm)

// バイアステープパラメータ
float BiasUnitLength = 300;        // 購入単位の長さ (cm)
float BiasUnitPrice = 330;         // 購入単位あたりの価格 (円)
float BiasShippingFee1 = 250;      // 1-10個の送料 (円)
float BiasShippingFee2 = 480;      // 11-20個の送料 (円)
float BiasShippingFee3 = 680;      // 21個以上の送料 (円)

// 制約パラメータ
float Budget = 50000;              // 予算 (円)
int BalanceAB = 10;                // タオルA-B間のバランス許容値
int BalancePattern = 2;            // 柄間のバランス許容値

// 目的関数の重み
float WeightWaste = 100;           // 廃棄量の重み
float WeightProfit = 1;            // 利益の重み

// 決定変数
dvar int+ cotton_A_units;          // タオルA用綿生地の購入単位数
dvar int+ cotton_B_units;          // タオルB用綿生地の購入単位数
dvar int+ bias_units;              // バイアステープの購入単位数（全柄共通）
dvar int+ towel_A[Patterns];       // タオルAの製造枚数（柄別）
dvar int+ towel_B[Patterns];       // タオルBの製造枚数（柄別）

// 補助変数
dvar boolean cotton_shipping_free; // 綿生地送料無料フラグ
dvar int+ bias_shipping_tier in 0..2;  // バイアステープ送料ティア (0:1-10, 1:11-20, 2:21+)
dvar int+ rows_A;                  // タオルAの行数
dvar int+ rows_B;                  // タオルBの行数

// 式定義
dexpr int total_towel_A = sum(p in Patterns) towel_A[p];
dexpr int total_towel_B = sum(p in Patterns) towel_B[p];

// 綿生地の使用量と廃棄量
dexpr float cotton_A_used = total_towel_A * TowelA_Height;
dexpr float cotton_A_waste = cotton_A_units * CottonUnitLength - cotton_A_used;
dexpr float cotton_B_used = total_towel_B * TowelB_Height;
dexpr float cotton_B_waste = cotton_B_units * CottonUnitLength - cotton_B_used;

// バイアステープの使用量と廃棄量（柄別）
dexpr float bias_used[p in Patterns] = towel_A[p] * TowelA_BiasLength + towel_B[p] * TowelB_BiasLength;
dexpr float bias_waste[p in Patterns] = bias_units * BiasUnitLength - bias_used[p];
dexpr float total_bias_waste = sum(p in Patterns) bias_waste[p];

// 総廃棄量
dexpr float total_waste = cotton_A_waste + cotton_B_waste + total_bias_waste;

// コスト計算
dexpr float cotton_cost = (cotton_A_units + cotton_B_units) * CottonUnitPrice;
dexpr float bias_cost = bias_units * BiasUnitPrice * NbPatterns;
dvar float+ cotton_shipping;
dvar float+ bias_shipping;
dexpr float total_cost = cotton_cost + bias_cost + cotton_shipping + bias_shipping;

// 収益計算
dexpr float total_revenue = total_towel_A * TowelA_Price + total_towel_B * TowelB_Price;
dexpr float total_profit = total_revenue - total_cost;

// 目的関数: 廃棄最小化と収益最大化の重み付け
minimize WeightWaste * total_waste - WeightProfit * total_profit;

// 制約条件
subject to {
    // 1. 予算制約
    ctBudget:
        total_cost <= Budget;
    
    // 2. 綿生地A配置制約
    // 2.1 横方向: タオルAは2枚/行で満杯
    ctCottonA_Horizontal:
        total_towel_A == rows_A * TowelA_PerRow;
    
    // 2.2 縦方向: 使用量が購入量を超えない
    ctCottonA_Vertical:
        cotton_A_used <= cotton_A_units * CottonUnitLength;
    
    // 2.3 縦方向廃棄: タオルAが作れない量（35cm未満）
    ctCottonA_Waste:
        cotton_A_waste <= TowelA_Height - 1;
    
    // 3. 綿生地B配置制約
    // 3.1 横方向: タオルBは3枚/行で満杯
    ctCottonB_Horizontal:
        total_towel_B == rows_B * TowelB_PerRow;
    
    // 3.2 縦方向: 使用量が購入量を超えない
    ctCottonB_Vertical:
        cotton_B_used <= cotton_B_units * CottonUnitLength;
    
    // 3.3 縦方向廃棄: タオルBが作れない量（35cm未満）
    ctCottonB_Waste:
        cotton_B_waste <= TowelB_Height - 1;
    
    // 4. バイアステープ制約（各柄）
    forall(p in Patterns) {
        // 4.1 使用量が購入量を超えない
        ctBias_Usage:
            bias_used[p] <= bias_units * BiasUnitLength;
        
        // 4.2 廃棄: タオルA・B両方が作れない量（152cm未満）
        ctBias_Waste:
            bias_waste[p] <= TowelB_BiasLength - 1;
    }
    
    // 5. 最小製造数制約
    forall(p in Patterns) {
        ctMinTowelA:
            towel_A[p] >= 1;
        ctMinTowelB:
            towel_B[p] >= 1;
    }
    
    // 6. バランス制約
    // 6.1 タオルA-B間のバランス
    ctBalance_AB_Upper:
        total_towel_A - total_towel_B <= BalanceAB;
    ctBalance_AB_Lower:
        total_towel_B - total_towel_A <= BalanceAB;
    
    // 6.2 タオルA内の柄バランス
    forall(p1 in Patterns, p2 in Patterns: p1 < p2) {
        ctBalance_A_Upper:
            towel_A[p1] - towel_A[p2] <= BalancePattern;
        ctBalance_A_Lower:
            towel_A[p2] - towel_A[p1] <= BalancePattern;
    }
    
    // 6.3 タオルB内の柄バランス
    forall(p1 in Patterns, p2 in Patterns: p1 < p2) {
        ctBalance_B_Upper:
            towel_B[p1] - towel_B[p2] <= BalancePattern;
        ctBalance_B_Lower:
            towel_B[p2] - towel_B[p1] <= BalancePattern;
    }
    
    // 7. 綿生地送料制約
    ctCottonShipping1:
        cotton_shipping >= 0;
    ctCottonShipping2:
        cotton_shipping <= CottonShippingFee;
    ctCottonShipping3:
        cotton_shipping >= CottonShippingFee - (CottonShippingFee + 1) * cotton_shipping_free;
    ctCottonShipping4:
        cotton_cost >= CottonShippingThreshold - 100000 * (1 - cotton_shipping_free);
    ctCottonShipping5:
        cotton_cost <= CottonShippingThreshold - 1 + 100000 * cotton_shipping_free;
    
    // 8. バイアステープ送料制約
    ctBiasShipping1:
        bias_shipping >= BiasShippingFee1 - 1000 * bias_shipping_tier;
    ctBiasShipping2:
        bias_shipping >= BiasShippingFee2 - 1000 * (1 - bias_shipping_tier);
    ctBiasShipping3:
        bias_shipping >= BiasShippingFee2 - 1000 * (2 - bias_shipping_tier);
    ctBiasShipping4:
        bias_shipping <= BiasShippingFee1 + 1000 * bias_shipping_tier;
    ctBiasShipping5:
        bias_shipping <= BiasShippingFee2 + 1000 * (bias_shipping_tier - 1);
    ctBiasShipping6:
        bias_shipping <= BiasShippingFee3;
    ctBiasShipping7:
        bias_units * NbPatterns <= 10 + 1000 * bias_shipping_tier;
    ctBiasShipping8:
        bias_units * NbPatterns >= 11 - 1000 * (1 - bias_shipping_tier);
    ctBiasShipping9:
        bias_units * NbPatterns <= 20 + 1000 * (2 - bias_shipping_tier);
    ctBiasShipping10:
        bias_units * NbPatterns >= 21 - 1000 * (2 - bias_shipping_tier);
}

// 結果出力
execute DISPLAY {
    writeln("=== タオル製造最適化結果 ===");
    writeln();
    
    writeln("【購入材料】");
    writeln("綿生地A: ", cotton_A_units * CottonUnitLength, "cm (", cotton_A_units, "単位) - ", 
            cotton_A_units * CottonUnitPrice, "円");
    writeln("綿生地B: ", cotton_B_units * CottonUnitLength, "cm (", cotton_B_units, "単位) - ", 
            cotton_B_units * CottonUnitPrice, "円");
    writeln("バイアステープ: ", bias_units * BiasUnitLength, "cm (", bias_units, "単位×4柄) - ", 
            bias_units * BiasUnitPrice * NbPatterns, "円");
    writeln("綿生地送料: ", cotton_shipping, "円");
    writeln("バイアステープ送料: ", bias_shipping, "円");
    writeln("総コスト: ", total_cost, "円");
    writeln();
    
    writeln("【製造枚数】");
    write("タオルA: ", total_towel_A, "枚 (");
    for(var p in Patterns) {
        write(PatternNames[p], ":", towel_A[p]);
        if(p < NbPatterns) write(", ");
    }
    writeln(")");
    
    write("タオルB: ", total_towel_B, "枚 (");
    for(var p in Patterns) {
        write(PatternNames[p], ":", towel_B[p]);
        if(p < NbPatterns) write(", ");
    }
    writeln(")");
    writeln("合計: ", total_towel_A + total_towel_B, "枚");
    writeln();
    
    writeln("【収益】");
    writeln("タオルA売上: ", total_towel_A * TowelA_Price, "円");
    writeln("タオルB売上: ", total_towel_B * TowelB_Price, "円");
    writeln("総売上: ", total_revenue, "円");
    writeln("総利益: ", total_profit, "円");
    writeln("収益率: ", Opl.round(total_revenue / total_cost * 1000) / 10, "%");
    writeln();
    
    writeln("【廃棄量】");
    writeln("綿生地A廃棄: ", Opl.round(cotton_A_waste * 10) / 10, "cm");
    writeln("綿生地B廃棄: ", Opl.round(cotton_B_waste * 10) / 10, "cm");
    for(var p in Patterns) {
        writeln("バイアステープ(", PatternNames[p], ")廃棄: ", Opl.round(bias_waste[p] * 10) / 10, "cm");
    }
    writeln("総廃棄量: ", Opl.round(total_waste * 10) / 10, "cm");
    writeln();
    
    writeln("【タオルAのコスト】");
    var cotton_A_cost_per_towel = (cotton_A_units * CottonUnitPrice) / total_towel_A;
    var bias_A_cost_per_towel = 0;
    for(var p in Patterns) {
        bias_A_cost_per_towel += (towel_A[p] * TowelA_BiasLength / (bias_units * BiasUnitLength)) *
                                  (bias_units * BiasUnitPrice) / total_towel_A;
    }
    var shipping_A_per_towel = (cotton_shipping + bias_shipping) * (total_towel_A / (total_towel_A + total_towel_B)) / total_towel_A;
    var total_A_cost_per_towel = cotton_A_cost_per_towel + bias_A_cost_per_towel + shipping_A_per_towel;
    writeln("綿生地コスト/枚: ", Opl.round(cotton_A_cost_per_towel * 100) / 100, "円");
    writeln("バイアステープコスト/枚: ", Opl.round(bias_A_cost_per_towel * 100) / 100, "円");
    writeln("送料/枚: ", Opl.round(shipping_A_per_towel * 100) / 100, "円");
    writeln("合計コスト/枚: ", Opl.round(total_A_cost_per_towel * 100) / 100, "円");
    writeln("利益/枚: ", Opl.round((TowelA_Price - total_A_cost_per_towel) * 100) / 100, "円");
    writeln();
    
    writeln("【タオルBのコスト】");
    var cotton_B_cost_per_towel = (cotton_B_units * CottonUnitPrice) / total_towel_B;
    var bias_B_cost_per_towel = 0;
    for(var p in Patterns) {
        bias_B_cost_per_towel += (towel_B[p] * TowelB_BiasLength / (bias_units * BiasUnitLength)) *
                                  (bias_units * BiasUnitPrice) / total_towel_B;
    }
    var shipping_B_per_towel = (cotton_shipping + bias_shipping) * (total_towel_B / (total_towel_A + total_towel_B)) / total_towel_B;
    var total_B_cost_per_towel = cotton_B_cost_per_towel + bias_B_cost_per_towel + shipping_B_per_towel;
    writeln("綿生地コスト/枚: ", Opl.round(cotton_B_cost_per_towel * 100) / 100, "円");
    writeln("バイアステープコスト/枚: ", Opl.round(bias_B_cost_per_towel * 100) / 100, "円");
    writeln("送料/枚: ", Opl.round(shipping_B_per_towel * 100) / 100, "円");
    writeln("合計コスト/枚: ", Opl.round(total_B_cost_per_towel * 100) / 100, "円");
    writeln("利益/枚: ", Opl.round((TowelB_Price - total_B_cost_per_towel) * 100) / 100, "円");
    writeln();
    
    // タオルA配置図の描画
    writeln("【タオルA配置図】");
    writeln("綿生地: 幅", CottonWidth, "cm × 長さ", cotton_A_units * CottonUnitLength, "cm");
    writeln();
    
    // 簡易的な配置図を描画
    writeln("タオルA配置 (", TowelA_PerRow, "枚/行):");
    var towel_count_A = 0;
    var row_num_A = 1;
    for(var p in Patterns) {
        for(var i = 1; i <= towel_A[p]; i++) {
            if(towel_count_A % TowelA_PerRow == 0) {
                if(towel_count_A > 0) writeln();
                write("  行", row_num_A, ": ");
                row_num_A++;
            }
            write("[", PatternNames[p], "] ");
            towel_count_A++;
        }
    }
    writeln();
    if(cotton_A_waste > 0) {
        writeln("  [廃棄: ", Opl.round(cotton_A_waste * 10) / 10, "cm]");
    }
    writeln();
    
    // タオルB配置図の描画
    writeln("【タオルB配置図】");
    writeln("綿生地: 幅", CottonWidth, "cm × 長さ", cotton_B_units * CottonUnitLength, "cm");
    writeln();
    
    // 簡易的な配置図を描画
    writeln("タオルB配置 (", TowelB_PerRow, "枚/行 + 横廃棄5cm):");
    var towel_count_B = 0;
    var row_num_B = 1;
    for(var p in Patterns) {
        for(var i = 1; i <= towel_B[p]; i++) {
            if(towel_count_B % TowelB_PerRow == 0) {
                if(towel_count_B > 0) writeln(" [廃棄5cm]");
                write("  行", row_num_B, ": ");
                row_num_B++;
            }
            write("[", PatternNames[p], "] ");
            towel_count_B++;
        }
    }
    writeln(" [廃棄5cm]");
    if(cotton_B_waste > 0) {
        writeln("  [縦廃棄: ", Opl.round(cotton_B_waste * 10) / 10, "cm]");
    }
    writeln();
    writeln("注: タオルBの右側5cmは横方向の構造的廃棄です");
}
