/*********************************************
 * OPL Model
 * キャンペーンメール送付最適化モデル
 * 
 * 目的: 期待収益を最大化
 * 制約: 予算制約、配信制限制約
 * 
 * Author: IBM Cloud DO-CPLEX
 * Date: 2026-03-06
 *********************************************/

/*********************
 * データ定義
 *********************/

// 顧客データの構造定義
tuple TCustomer {
  key string customer_id;
  float conv_prob_campaign1;
  float conv_prob_campaign2;
  float conv_prob_campaign3;
};

// CSVファイルから顧客データを読み込み
{TCustomer} Customers = ...;

// キャンペーン数
int NbCampaigns = 3;
range Campaigns = 1..NbCampaigns;

// キャンペーン情報
string campaignNames[Campaigns] = ["バッグ", "インナーウェア", "アクセサリー"];

// キャンペーンごとのクーポンコスト（円）
float couponCost[Campaigns] = [5000, 3000, 7000];

// キャンペーンごとのコンバージョン時の収益（円）
float revenue[Campaigns] = [20000, 15000, 25000];

// 制約パラメータ
float totalBudget = 200000;           // 総予算（円）
int maxEmailsPerCustomer = 2;         // 各顧客への最大配信数

/*********************
 * 決定変数
 *********************/

// 顧客cにキャンペーンkを送るかどうか (0 or 1)
dvar boolean send[c in Customers][k in Campaigns];

/*********************
 * 式定義
 *********************/

// 各顧客×キャンペーンの期待利益
// 期待利益 = (コンバージョン確率 × 収益) - クーポンコスト
dexpr float expectedProfit[c in Customers][k in Campaigns] = 
  (k == 1) ? (c.conv_prob_campaign1 * revenue[k] - couponCost[k]) :
  (k == 2) ? (c.conv_prob_campaign2 * revenue[k] - couponCost[k]) :
             (c.conv_prob_campaign3 * revenue[k] - couponCost[k]);

// 総期待利益
dexpr float totalExpectedProfit = 
  sum(c in Customers, k in Campaigns) 
    send[c][k] * expectedProfit[c][k];

// 総コスト
dexpr float totalCost =
  sum(c in Customers, k in Campaigns)
    send[c][k] * couponCost[k];

// 総配信メール数
dexpr int totalEmailsSent =
  sum(c in Customers, k in Campaigns) send[c][k];

// キャンペーン別配信数
dexpr int campaignSent[k in Campaigns] = 
  sum(c in Customers) send[c][k];

// キャンペーン別コスト
dexpr float campaignCost[k in Campaigns] = 
  sum(c in Customers) send[c][k] * couponCost[k];

// キャンペーン別期待利益
dexpr float campaignProfit[k in Campaigns] = 
  sum(c in Customers) send[c][k] * expectedProfit[c][k];

/*********************
 * 目的関数
 *********************/

// 総期待利益を最大化
maximize totalExpectedProfit;

/*********************
 * 制約条件
 *********************/

subject to {
  // 予算制約: 総コストは予算以下
  ctBudget:
    totalCost <= totalBudget;
  
  // 配信制限制約: 各顧客への配信は最大2通まで
  forall(c in Customers)
    ctMaxEmails:
      sum(k in Campaigns) send[c][k] <= maxEmailsPerCustomer;
}

/*********************
 * 出力データ定義
 *********************/

// Solution: Customer delivery plan
tuple TSolution {
  string customer_id;
  int campaign1_send;
  int campaign2_send;
  int campaign3_send;
  int total_emails;
  float expected_profit;
  float cost;
};

{TSolution} solution = {};

// KPI: Key Performance Indicators
tuple TKPI {
  key string metric;
  float value;
};

{TKPI} kpis = {
  <"Total Expected Profit", totalExpectedProfit>,
  <"Total Cost", totalCost>,
  <"Budget Utilization Rate", totalCost / totalBudget * 100>,
  <"Total Emails Sent", totalEmailsSent>,
  <"Campaign 1 Sent", campaignSent[1]>,
  <"Campaign 2 Sent", campaignSent[2]>,
  <"Campaign 3 Sent", campaignSent[3]>
};

// Campaign statistics
tuple TCampaignStats {
  string campaign_name;
  int emails_sent;
  float total_cost;
  float expected_profit;
  float roi_percent;
};

{TCampaignStats} campaign_stats = {};

// Calculate campaign statistics and solution using post-processing
execute INITIALIZE_DATA {
  // Add campaign statistics
  campaign_stats.add(
    campaignNames[1],
    campaignSent[1],
    campaignCost[1],
    campaignProfit[1],
    (campaignCost[1] > 0) ? (campaignProfit[1] / campaignCost[1] * 100) : 0
  );
  campaign_stats.add(
    campaignNames[2],
    campaignSent[2],
    campaignCost[2],
    campaignProfit[2],
    (campaignCost[2] > 0) ? (campaignProfit[2] / campaignCost[2] * 100) : 0
  );
  campaign_stats.add(
    campaignNames[3],
    campaignSent[3],
    campaignCost[3],
    campaignProfit[3],
    (campaignCost[3] > 0) ? (campaignProfit[3] / campaignCost[3] * 100) : 0
  );
  
  // Add solution data for all customers
  for (var c in Customers) {
    var totalEmails = 0;
    var customerProfit = 0;
    var customerCost = 0;
    
    for (var k in Campaigns) {
      if (send[c][k] == 1) {
        totalEmails++;
        customerProfit += expectedProfit[c][k];
        customerCost += couponCost[k];
      }
    }
    
    solution.add(
      c.customer_id,
      send[c][1],
      send[c][2],
      send[c][3],
      totalEmails,
      customerProfit,
      customerCost
    );
  }
}

/*********************
 * 実行後の出力
 *********************/

execute {
  writeln("================================================================================");
  writeln("           キャンペーンメール送付最適化結果");
  writeln("================================================================================");
  writeln("");
  
  writeln("【全体サマリー】");
  writeln("  総期待利益:     ", Opl.round(totalExpectedProfit), " 円");
  writeln("  総コスト:       ", Opl.round(totalCost), " 円");
  writeln("  予算:           ", totalBudget, " 円");
  writeln("  予算利用率:     ", Opl.round(totalCost / totalBudget * 100 * 10) / 10, " %");
  writeln("  総配信メール数: ", totalEmailsSent, " 通");
  
  if (totalCost > 0) {
    var overallROI = (totalExpectedProfit / totalCost) * 100;
    writeln("  期待ROI:        ", Opl.round(overallROI * 10) / 10, " %");
  }
  writeln("");
  
  writeln("【キャンペーン別統計】");
  for (var k in Campaigns) {
    writeln("  ■ キャンペーン", k, " (", campaignNames[k], ")");
    writeln("    配信数:       ", campaignSent[k], " 通");
    writeln("    総コスト:     ", Opl.round(campaignCost[k]), " 円");
    writeln("    期待利益:     ", Opl.round(campaignProfit[k]), " 円");
    
    if (campaignCost[k] > 0) {
      var roi = (campaignProfit[k] / campaignCost[k]) * 100;
      writeln("    期待ROI:      ", Opl.round(roi * 10) / 10, " %");
    }
    writeln("");
  }
  
  writeln("================================================================================");
  writeln("【顧客別配信計画】");
  writeln("================================================================================");
  writeln("");
  
  var sentCount = 0;
  var notSentCount = 0;
  
  for (var c in Customers) {
    var emailCount = 0;
    var campaigns = "";
    
    if (send[c][1] == 1) {
      emailCount++;
      campaigns += "キャンペーン1(バッグ) ";
    }
    if (send[c][2] == 1) {
      emailCount++;
      campaigns += "キャンペーン2(インナーウェア) ";
    }
    if (send[c][3] == 1) {
      emailCount++;
      campaigns += "キャンペーン3(アクセサリー) ";
    }
    
    if (emailCount > 0) {
      var customerProfit = 0;
      var customerCost = 0;
      
      for (var k in Campaigns) {
        if (send[c][k] == 1) {
          customerProfit += expectedProfit[c][k];
          customerCost += couponCost[k];
        }
      }
      
      writeln("顧客ID: ", c.customer_id);
      writeln("  配信: ", campaigns, "(", emailCount, "通)");
      writeln("  コスト: ", Opl.round(customerCost), " 円");
      writeln("  期待利益: ", Opl.round(customerProfit), " 円");
      writeln("");
      
      sentCount++;
    } else {
      notSentCount++;
    }
  }
  
  writeln("================================================================================");
  writeln("【配信統計】");
  writeln("  配信対象顧客数: ", sentCount, " 名");
  writeln("  配信なし顧客数: ", notSentCount, " 名");
  writeln("  総顧客数:       ", sentCount + notSentCount, " 名");
  writeln("================================================================================");
  writeln("");
  writeln("最適化完了");
  writeln("");
}
